<hr>
<div class="container text-center">
    <div class="row">
        <div class="col-lg-12">
            <ul class="nav nav-pills nav-justified">
                <li>© 2022 ACSLab, IIT Mandi</li>
                <li>Credits: Varun Dutt and Megha Sharma.</li>
            </ul>
        </div>
    </div>
</div>
<hr>