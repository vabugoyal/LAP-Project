<?php 
	$conn = new mysqli("localhost", "u978805288_PEDV3", "Megha@123", "u978805288_PEDV3");
	$conn = mysqli_connect("localhost", "u978805288_PEDV3", "Megha@123", "u978805288_PEDV3");

?>