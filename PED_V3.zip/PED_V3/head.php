<!DOCTYPE html>
<html lang="en">
<head>
    <title>Phishing Email Detection Game</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=1024" />


<!--async -->
<script type="text/javascript">
  (function() {
    var config = {
      kitId: 'jxd4bhn'
    };
    var d = false;
    var tk = document.createElement('script');
    tk.src = '//use.typekit.net/' + config.kitId + '.js';
    tk.type = 'text/javascript';
    tk.async = 'true';
    tk.onload = tk.onreadystatechange = function() {
      var rs = this.readyState;
      if (d || rs && rs != 'complete' && rs != 'loaded') return;
      d = true;
      try { Typekit.load(config); } catch (e) {}
    };
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(tk, s);
  })();
</script>
<!--<script src="//use.typekit.net/jxd4bhn.js"></script>
<script>try{Typekit.load();}catch(e){}</script>-->
<meta property="og:site_name" content="Phishing Email Detection Game"/>
<meta name="author" content="Megha Sharma and Varun Dutt" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="msvalidate.01" content="A715CCF7512E918C7F99005F066E26EC" />
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:regular,semibold,italic,italicsemibold|PT+Sans:400,700,400italic,700italic|PT+Serif:400,700,400italic,700italic" rel="stylesheet" />
    <script src="js/highcharts.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <!--<link rel="shortcut icon" href="23.png" />
   <link rel="apple-touch-icon" href="apple-touch-icon.png" />-->
    <link rel="shortcut icon" href="21.png" />
   
    <style>
        .container1{
            width:400px;
        }
    </style>
    <style type="text/css">
        button{
    position:relative;
    left:50%;
}
    </style>
</head>